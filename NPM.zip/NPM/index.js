var generateName = require('sillyname');
var sillyName = generateName();
console.log(`My name is ${sillyName}.`);



